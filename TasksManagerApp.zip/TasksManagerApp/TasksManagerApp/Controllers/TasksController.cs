﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TasksManagerApp.Models;
using TasksManagerApp.Models.Model;

namespace WebApiTest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TasksController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly ITasks _repo;
        public TasksController(ITasks repo, IMapper mapper)
        {
            _repo = repo;
            _mapper = mapper;
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteTask(int id, bool showSubTasks = false)
        {
            try {
                var result = await _repo.getTaskByID(id, showSubTasks);
                if (result == null) return NotFound("Opooos");
                _repo.removeTask(result);
                if (await _repo.SaveChangesAsync())
                {
                    return Ok("Deleted Successfully");
                }
                else
                {
                    return BadRequest();
                }
            }
            catch(Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateTask(int id, MainTask task)
        {
            try
            {
                var result = await _repo.getTaskByID(id);
                if (result == null) return NotFound("Opooos");
                result.TaskName = task.TaskName;
                result.TaskStartDate = task.TaskStartDate;
                result.TaskEndDate = task.TaskEndDate;
                result.TaskDetails = task.TaskDetails;
                if (await _repo.SaveChangesAsync())
                {
                    return Ok("Updated Successfully");
                }

                return Ok("No Values changed");
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet("{id}")]
        [Route("{id}",Name ="GetTask")]
        public async Task<ActionResult> GetTaskByID(int id, bool showSubTasks = false)
        {
            var result = await _repo.getTaskByID(id,showSubTasks);
            if (result == null) return NotFound("Opooos");
              return Ok(result);
        }
   
        [HttpPost]
        public async Task<ActionResult> AddTask(MainTask task)
        {
            try
            {
                if (ModelState.IsValid)
                {
                     _repo.addTask(task);
                    if (await _repo.SaveChangesAsync())
                    {
                        return Ok("Added Successfully");
                        //return CreatedAtRoute("GetTask", new { id = task.MainTaskID },task);
                    }
                    else
                    {
                        return BadRequest("Something went wrong");
                    }
                }
            }
            catch(Exception ex)
            {
                return BadRequest("Exception "+ex);
            }
            return BadRequest("Model is not valid");
        }
        
        [HttpGet]
        public async Task<ActionResult> GetTasks(bool showSubTasks=false)
        {
            try
            {
                var data = await _repo.getTasks(showSubTasks);
               // var result = _mapper.Map<IEnumerable<PersonModel>>(data);
                return Ok(data);
            }
            catch(Exception ex)
            {
                return BadRequest("Error" + ex);
            }
            
        }
    }

}