﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TasksManagerApp.Models.Model;

namespace TasksManagerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubTasksController : ControllerBase
    {
        private readonly ITasks _repo;
        public SubTasksController(ITasks repo)
        {
            _repo = repo;
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteSubTask(int id)
        {
            try
            {
                var result = await _repo.getSubTaskByID(id);
                if (result == null) return NotFound("Id is not correct/Something is wrong");
                _repo.removeSubTask(result);
                if (await _repo.SaveChangesAsync())
                {
                    return Ok("Deleted Successfully");
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateSubTask(int id, SubTask task)
        {
            try
            {
                var result = await _repo.getSubTaskByID(id);
                if (result == null) return NotFound("Id is not correct/Something is wrong");
                result.SubTaskName = task.SubTaskName;
                result.SubTaskStartDate = task.SubTaskStartDate;
                result.SubTaskEndDate = task.SubTaskEndDate;
                result.SubTaskDetails = task.SubTaskDetails;
                if (await _repo.SaveChangesAsync())
                {
                    return Ok("Updated Successfully");
                }

                return Ok("No Values changed");
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet("{id}")]
        [Route("{id}", Name = "GetSubTask")]
        public async Task<ActionResult> GetSubTaskByID(int id)
        {
            var result = await _repo.getSubTaskByID(id);
            if (result == null) return NotFound("Id is not correct/Something is wrong");
            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> AddSubTask(SubTask task)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _repo.addSubTask(task);
                    if (await _repo.SaveChangesAsync())
                    {
                        return Ok("Added Successfully");
                       // return CreatedAtRoute("GetSubTask", new { id = task.SubTaskID }, task);
                    }
                    else
                    {
                        return BadRequest("Something went wrong");
                    }
                }
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
            return BadRequest("Model is not valid");
        }

    }
}