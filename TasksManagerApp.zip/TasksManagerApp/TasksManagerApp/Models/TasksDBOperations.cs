﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TasksManagerApp.Models.Model;

namespace TasksManagerApp.Models
{
    public class TasksDBOperations : ITasks
    {
        private  readonly TasksDbContext _con;
        public TasksDBOperations(TasksDbContext con)
        {
            _con = con;
        }
        public void addTask(MainTask task)
        {
            _con.MainTasks.Add(task);
        }
        public void removeTask(MainTask task)
        {
            _con.MainTasks.Remove(task);
        }

        public async Task<MainTask> getTaskByID(int id,bool showSubTasks=false)
        {
            IQueryable<MainTask> q = _con.MainTasks;
            if (showSubTasks)
            {
                q = q.Include(m => m.SubTasks);
            }
           return await q.Where(m => m.MainTaskID == id).FirstOrDefaultAsync();
        }

        public async Task<List<MainTask>> getTasks(bool showSubTasks= false)
        {
            IQueryable<MainTask> q = _con.MainTasks;
            if (showSubTasks)
            {
               q= q.Include(m => m.SubTasks);
            }
            return await q.ToListAsync();
        }

        public async Task<bool> SaveChangesAsync()
        {
            return (await _con.SaveChangesAsync()) > 0;
        }

        public async Task<SubTask> getSubTaskByID(int id)
        {
            return await _con.SubTasks.Where(s => s.SubTaskID == id).FirstOrDefaultAsync();
        }

        public void removeSubTask(SubTask task)
        {
            _con.SubTasks.Remove(task);
        }

        public void addSubTask(SubTask task)
        {
            _con.SubTasks.Add(task);
        }
    }
}
