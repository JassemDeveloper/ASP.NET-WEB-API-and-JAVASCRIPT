﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TasksManagerApp.Models.Model
{
    public interface ITasks
    {
        Task<bool> SaveChangesAsync();

        //Tasks Controller
        void addTask(MainTask task);
        void removeTask(MainTask task);
        Task<MainTask> getTaskByID(int id, bool showSubTasks = false);
        Task<List<MainTask>> getTasks(bool showSubTasks=false);

        //SubTasks Controller
        void addSubTask(SubTask task);
        Task<SubTask> getSubTaskByID(int id);
        void removeSubTask(SubTask task);

    }
}
