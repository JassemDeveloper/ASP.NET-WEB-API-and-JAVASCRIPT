﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TasksManagerApp.Models.Model;

namespace TasksManagerApp.Models
{
    public class TasksDbContext : DbContext
    {
        public DbSet<MainTask> MainTasks { get; set; }
        public DbSet<SubTask> SubTasks { get; set; }

        public TasksDbContext(DbContextOptions<TasksDbContext> dbContextOptions) : base(dbContextOptions)
        {
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            /*
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(@"Server=localhost\SQLEXPRESS;Database=TestDB;Trusted_Connection=True;");
            }
            */
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            /*
            modelBuilder.Entity<Person>(entity =>
            {
                entity.Property(e => e.ID)
                    .IsUnicode(true);
            });
            */
        }
        }
}
