﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TasksManagerApp.Models.Model
{
    public class MainTask
    {
        [Key]
        public int MainTaskID { get; set; }
        [Required]
        public string TaskName { get; set; }
        [Required]
        public DateTime TaskStartDate { get; set; }
        [Required]
        public DateTime TaskEndDate { get; set; }
        [Required]
        public string TaskDetails { get; set; }
        public List<SubTask> SubTasks { get; set; }
        
    }
}
