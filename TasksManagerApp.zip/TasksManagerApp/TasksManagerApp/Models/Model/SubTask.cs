﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TasksManagerApp.Models.Model
{
    public class SubTask
    {
        [Key]
        public int SubTaskID { get; set; }
        public string SubTaskName { get; set; }
        public DateTime SubTaskStartDate { get; set; }
        public DateTime SubTaskEndDate { get; set; }
        public string SubTaskDetails { get; set; }
        public int MainTaskID { get; set; }
        public MainTask MainTask { get; set; }
    }
}
