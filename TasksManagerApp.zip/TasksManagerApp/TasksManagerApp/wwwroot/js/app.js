﻿
console.dir(navigator.appName);

getData(function (data) {
    let d = JSON.parse(data);
    TableTemplate(d);
    document.querySelector('.container').addEventListener('click', function (e) {
        switchAction(e);
    });
},"tasks");

function reloadData() {
    getData(function (data) {
        let d = JSON.parse(data);
        TableTemplate(d);
    }, "tasks");

}
function showSubTask(e) {
    /*
    if (e.target.innerText == "Hide") {
        e.target.innerText = "Show";
    } else {
        e.target.innerText = "Hide";
    }
    */
    let subTaskRow = e.target.parentElement.parentElement.nextSibling;
    let currentRow = e.target;
    console.log(currentRow);
    currentRow.classList.toggle("fa-eye-slash"); 
    subTaskRow.classList.toggle('show-subTask');
}

function newSubTaskForm(id) {
    let form = `
        <form>
            <input type='hidden' name='mainTaskID' value='${id}'>
            <label>Sub Task Name</label>
            <input type="text" name="subTaskName" required />
            <label>Sub Task Start Date</label>
            <input type="datetime" class="datetime-field" name="subTaskStartDate" required readonly />
            <label>Sub Task End Date</label>
            <input type="datetime" class="datetime-field" name="subTaskEndDate" required readonly/>
            <label>Sub Task Details</label>
            <input type="text" name="subTaskDetails" required />
        </form>
 <button class='btn' data-action="saveSubTask" data-type='subTasks'>Save Sub Task</button>
            <button class='btn' data-action="closeForm">Close</button>
`;
    document.querySelector('.form').innerHTML = form;
    animateForm();
    tail.DateTime(".datetime-field", {
        dateFormat: "mm/dd/YYYY",
        timeFormat: "HH:ii:ss",
        stayOpen: false,
        today: true
    });

}

function updateSubTaskForm(id, type) {
    getDataById(function (data) {
        let d = JSON.parse(data);
        let form = `
        <form>
            <input type="hidden" name="mainTaskID" value="${d.mainTaskID}" required />
            <label>Sub Task Name</label>
            <input type="text" name="subTaskName" value="${d.subTaskName}" required />
            <label>Sub Task Start Date</label>
            <input type="datetime"  class="datetime-field" name="subTaskStartDate" value="${d.subTaskStartDate}" required readonly />
            <label>Sub Task End Date</label>
            <input type="datetime" class="datetime-field" name="subTaskEndDate" value="${d.subTaskEndDate}" required readonly/>
            <label>Sub Task Details</label>
            <input type="text" name="subTaskDetails" value="${d.subTaskDetails}" required />
        </form>
 <button class='btn' data-action="updateTask" data-id='${d.subTaskID}' data-type='subTasks'>Update Sub Task</button>
            <button class='btn' data-action="closeForm">Close</button>
`;
        document.querySelector('.form').innerHTML = form;
        animateForm();
        tail.DateTime(".datetime-field", {
            dateFormat: "mm/dd/YYYY",
            timeFormat: "HH:ii:ss",
            stayOpen: false,
            today: true
        });
    }, id, type);
}

function checkDate(startDate, endDate) {
    let start = new Date(startDate).getTime();
    let end = new Date(endDate).getTime();
    if (end > start) {
        return true;
    }
    return false;
}

function getDaysTwoDates(startDate, endDate) {
    let start = new Date(startDate).getTime();
    let end = new Date(endDate).getTime();
    let days = (end - start) / (1000 * 24 * 3600);
    return Math.ceil(days);
}

console.log(getDaysTwoDates("1/1/2020", "1/2/2020"));
function formateDate(date) {
    let da = new Date(date);
    let m = (da.getMonth() + 1) < 10 ? 0 + "" + (da.getMonth() + 1) : (da.getMonth() + 1) ;
    let y = da.getFullYear();
    let d = da.getDate() < 10 ? 0+""+da.getDate():da.getDate();
    let mm = da.getMinutes() < 10 ? 0 + "" + da.getMinutes() : da.getMinutes();
    let ss = da.getSeconds() < 10 ? 0 + "" + da.getSeconds() : da.getSeconds();
    let hh = da.getHours() < 10 ? 0 + "" + da.getHours() : da.getHours();

    let format = `${m}/${d}/${y} ${hh}:${mm}:${ss}`;

    return format;
}

//console.log(checkDate("04/19/2020 19:20:00", "04/10/2020 21:20:00"));

function animateForm() {
    let formCont = document.querySelector(".form");
    if (formCont.classList.contains('slowFormDown')) {
        formCont.classList.remove('slowFormDown');
        formCont.classList.add('slowFormUp');
        setTimeout(function () {
            formCont.innerHTML = "";
            formCont.classList.remove('slowFormUp');
        }, 500);
    } else if (formCont.classList.contains('slowFormUp')) {
        formCont.classList.add('slowFormDown');
        formCont.classList.remove('slowFormUp');
    } else {
        formCont.classList.add('slowFormDown');
    }
}
function newTaskForm() {
    
    let form = `
        <form>
            <label>Task Name</label>
            <input type="text" name="taskName" required />
            <label>Task Start Date</label>
            <input type="datetime" class="datetime-field" name="taskStartDate" required readonly />
            <label>Task End Date</label>
            <input type="datetime" class="datetime-field"  name="taskEndDate" required readonly/>
            <label>Task Details</label>
            <input type="text" name="taskDetails" required />
        </form>
 <button class='btn' data-action="saveTask" data-type="tasks">Save Task</button>
            <button class='btn' data-action="closeForm">Close</button>
`;
    
    document.querySelector('.form').innerHTML = form;
    animateForm();
    tail.DateTime(".datetime-field", {
        dateFormat: "mm/dd/YYYY",
        timeFormat: "HH:ii:ss",
        stayOpen: false,
        today: true
    });
}

function updateTaskForm(id,type) {
    getDataById(function (data) {
        let d = JSON.parse(data);
        let form = `
        <form>
            <label>Task Name</label>
            <input type="text" name="taskName" value="${d.taskName}" required />
            <label>Task Start Date</label>
            <input type="datetime" class="datetime-field" name="taskStartDate" value="${d.taskStartDate}" required readonly />
            <label>Task End Date</label>
            <input type="datetime"  class="datetime-field" name="taskEndDate"  value="${d.taskEndDate}" required readonly/>
            <label>Task Details</label>
            <input type="text" name="taskDetails" value="${d.taskDetails}" required />
        </form>
 <button class='btn' data-action="updateTask" data-id='${d.mainTaskID}' data-type="tasks">Update Task</button>
            <button class='btn' data-action="closeForm">Close</button>
`;
        document.querySelector('.form').innerHTML = form;
        animateForm();
        tail.DateTime(".datetime-field", {
            dateFormat: "mm/dd/YYYY",
            timeFormat: "HH:ii:ss",
            stayOpen: false,
            today: true
        });
    }, id,type);
}
function getFormData() {
    let form = document.querySelector('form');
    let elements = form.elements;
    let obj = {};
    let final = {};
    let errors = [];
       Array.prototype.slice.call(elements).forEach(function (el) {
        if (el.type != 'submit') {
            obj[el.name] = el.value;
            if (el.value.length == 0) {
                let name = el.name;
                errors.push({
                   name : "Please fill in this field"
                });
            }
        }
       });
    if (errors.length > 0) {
        final['isValid'] = false;
        final['errors'] = errors;
    } else {
        final['isValid'] = true;
        final['data'] = obj;
    }
    return final;
}

function switchAction(e) {
    let action = e.target.getAttribute("data-action");
    let id = e.target.getAttribute("data-id");
    let type = e.target.getAttribute("data-type");

    switch (action) {
        case "showSub":
            showSubTask(e);
            break;
        case "addSubTask":
            newSubTaskForm(id);
            break;
        case "newTask":
            newTaskForm();
            break;
        case "saveTask":
            saveData(type);
            reloadData();
            break;
        case "saveSubTask":
            saveData(type);
            reloadData();
            break;
        case "updateTask":
            updateData1(id, type);
            reloadData();
            break;
        case "updateSubTask":
            updateData(id, type);
            reloadData();
            break;
        case "edit":
            if (type == "tasks") {
                updateTaskForm(id,type);
            } else {
                updateSubTaskForm(id,type);
            }
            break;
        case "delete":
            deleteData(id, type, e);
            break;
        case "closeForm":
            animateForm();
            //document.querySelector('.form').innerHTML = "";
            break;
    }
}

function getDataById(callBack,id,type) {
    let url = `api/${type}/${id}`;
    let xmlHttp = new XMLHttpRequest();
    xmlHttp.open("GET", url, false);
    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4 || xmlHttp.status == 200) {
            callBack(xmlHttp.responseText);
        }
    }
    xmlHttp.send();
}

function getData(callBack,type) {
    let url = `api/${type == "tasks" ? type+"?showSubTasks=true":type}`;
    let xmlHttp = new XMLHttpRequest();
    xmlHttp.open("GET", url,false);
    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4 || xmlHttp.status == 200) {
            callBack(xmlHttp.responseText);
        }
    }
    xmlHttp.send();
}

function deleteData(id, type, event) {
    let url = `api/${type}/${id}`;
    let xmlHttp = new XMLHttpRequest();
    xmlHttp.open("DELETE", url, false);
    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4 && xmlHttp.status == "200") {
            showMessage(xmlHttp.responseText, "success");
            let el = event.target.parentElement.parentElement;
            let count = el.parentElement.childElementCount;
            let mainTaskclassName = el.parentElement.parentElement.parentElement.className;
            let SubTaskclassName = el.parentElement.parentElement.className;
            if (count == 2 && SubTaskclassName == "s-t" || count == 3 && mainTaskclassName == "data") {
                if (mainTaskclassName == "data") {
                    document.querySelector('.data').innerHTML = "<span>No Tasks have been added Yet</span>";
                } else if (SubTaskclassName == "s-t") {
                    el.parentElement.parentElement.parentElement.parentElement.previousElementSibling.lastElementChild.querySelector('.fa-eye-slash').remove()
                    el.parentElement.parentElement.remove();
                }
            } else {
                el.parentElement.removeChild(el);
            }

        } else {
            showMessage("Something went wrong try again", "error");
            
        }
    }
   xmlHttp.send(null);
}

function saveData(type) {
    let isValid = getFormData();
    let withinRange = true;
    let isDateInRange = true;
    let isDateGreater = true;
    let daysInMT = 0;
    let daysInST = 0;
    let daysToBeUsed = 0;
    let formDatesDays = 0;
    if (isValid.isValid) {
            let checkDates = '';
            if (type == "tasks") {
                checkDates = checkDate(isValid.data.taskStartDate, isValid.data.taskEndDate)
            } else {
                checkDates = checkDate(isValid.data.subTaskStartDate, isValid.data.subTaskEndDate)
            }
        if (checkDates) {
            let d = isValid.data;
            if (type == "subTasks") {
                getDataById(function (d) {
                    let maData = JSON.parse(d);
                    daysInMT = getDaysTwoDates(maData.taskStartDate, maData.taskEndDate);
                    let taskStartDate = new Date(maData.taskStartDate).getTime();
                    let taskEndDate = new Date(maData.taskEndDate).getTime();
                    let subTaskStartDate = new Date(isValid.data.subTaskStartDate).getTime();
                    let subTaskEndDate = new Date(isValid.data.subTaskEndDate).getTime();
                    if (subTaskStartDate >= taskStartDate && subTaskStartDate <= taskEndDate) {
                        if (subTaskEndDate >= taskStartDate && subTaskEndDate <= taskEndDate) {
                            isDateInRange = true;
                        } else {
                            isDateInRange = false;
                        }
                    } else {
                        isDateInRange = false;
                    }
                    if (maData.subTasks.length > 0) {
                        daysInST = maData.subTasks.reduce(function (values, current) {
                            return values + getDaysTwoDates(current.subTaskStartDate, current.subTaskEndDate);
                        }, 0)
                        daysToBeUsed = daysInMT - daysInST;
                        daysToBeUsed = daysToBeUsed < 0 ? 0 : daysToBeUsed;
                        formDatesDays = getDaysTwoDates(isValid.data.subTaskStartDate, isValid.data.subTaskEndDate);
                        withinRange = (daysToBeUsed - formDatesDays) > -1 ? true : false;
                    }
                }, d.mainTaskID + "?showSubTasks=true", "tasks");
            }
            if (type == "tasks") {
                if (new Date(isValid.data.taskStartDate).getTime() >= new Date().getTime()) {
                    isDateGreater = true;
                } else {
                    isDateGreater = false;
                }
            }
            if (isDateGreater) {
                if (isDateInRange) {
                    if (withinRange) {
                        let data = JSON.stringify(isValid.data);
                        let url = `api/${type}`;
                        let xmlHttp = new XMLHttpRequest();
                        xmlHttp.open("POST", url, false);
                        xmlHttp.setRequestHeader('Content-type', 'application/json; charset=utf-8');
                        xmlHttp.onreadystatechange = function () {
                            if (xmlHttp.readyState == 4 || xmlHttp.status == 200) {
                                showMessage(xmlHttp.responseText, "success");
                            }
                        }
                        xmlHttp.send(data);
                    } else {
                        if (daysToBeUsed == 0) {
                            showMessage(`You  selected all the days in the main task`, "error");
                        } else {
                            showMessage(`You can select dates up to ${daysToBeUsed} day/s`, "error");
                        }
                    }
                } else {
                    showMessage(`Start/End Date is not in align with the main task start/end date`, "error");
                }
            } else {
                showMessage(`Start Date and time should be greater or equal to today's date`, "error");
        }
            } else {
                showMessage("Start Date or End Date is not in the correct range", "error");
            }
    } else {
        showMessage("please make sure all fields are filled", "error");
    }

}

function updateData1(id, type) {

    let isValid = getFormData();
    let withinRange = true;
    let isDateInRange = true;
    let isDateGreater = true;
    let canBeUpdated = true;
    let daysInMT = 0;
    let daysInST = 0;
    let daysToBeUsed = 0;
    let formDatesDays = 0;
    let maData = '';
    if (isValid.isValid) {
        let checkDates = '';
        if (type == "tasks") {
            checkDates = checkDate(isValid.data.taskStartDate, isValid.data.taskEndDate)
        } else {
            checkDates = checkDate(isValid.data.subTaskStartDate, isValid.data.subTaskEndDate)
        }
        if (checkDates) {
            let d = isValid.data;
            if (type == "subTasks") {
                getDataById(function (dd) {
                    maData = JSON.parse(dd);
                    daysInMT = getDaysTwoDates(maData.taskStartDate, maData.taskEndDate);
                    let taskStartDate = new Date(maData.taskStartDate).getTime();
                    let taskEndDate = new Date(maData.taskEndDate).getTime();
                    let subTaskStartDate = new Date(d.subTaskStartDate).getTime();
                    let subTaskEndDate = new Date(d.subTaskEndDate).getTime();
                    if (subTaskStartDate >= taskStartDate && subTaskStartDate <= taskEndDate) {
                        if (subTaskEndDate >= taskStartDate && subTaskEndDate <= taskEndDate) {
                            isDateInRange = true;
                        } else {
                            isDateInRange = false;
                        }
                    } else {
                        isDateInRange = false;
                    }
                    if (maData.subTasks.length > 0) {
                        daysInST = 0;
                        maData.subTasks.forEach(function (el) {
                            if (el.subTaskID != id) {
                                daysInST += getDaysTwoDates(el.subTaskStartDate, el.subTaskEndDate);
                            }
                        });
                      /*  daysInST = maData.subTasks.reduce(function (values, current) {
                            console.log(current.subTaskID);
                           // return current.subTaskID != id ? values + getDaysTwoDates(current.subTaskStartDate, current.subTaskEndDate) : 0;
                        });
                        */
                        formDatesDays = getDaysTwoDates(isValid.data.subTaskStartDate, isValid.data.subTaskEndDate) + daysInST;
                        daysToBeUsed = daysInMT - formDatesDays;
                        daysToBeUsed = daysToBeUsed < 0 ? -1 : daysToBeUsed;
                        withinRange = daysToBeUsed > -1 ? true : false;
                        daysToBeUsed = daysToBeUsed < 0 ? 0 : daysToBeUsed;

                    }
                }, d.mainTaskID + "?showSubTasks=true", "tasks");
            }

            if (type == "tasks") {
                getDataById(function (d) {
                    maData = JSON.parse(d);
                    daysInMT = getDaysTwoDates(maData.taskStartDate, maData.taskEndDate);
                    if (maData.subTasks.length > 0) {
                        daysInST = maData.subTasks.reduce(function (values, current) {
                            return values + getDaysTwoDates(current.subTaskStartDate, current.subTaskEndDate);
                        }, 0);
                        daysToBeUsed = daysInMT - daysInST;
                        daysToBeUsed = daysToBeUsed < 0 ? 0 : daysToBeUsed;
                        formDatesDays = getDaysTwoDates(isValid.data.taskStartDate, isValid.data.taskEndDate);
                        canBeUpdated = (formDatesDays - daysInST) > -1 ? true : false;
                        if (new Date(isValid.data.subTaskStartDate).getTime() >= new Date().getTime()) {
                            isDateGreater = true;
                        } else {
                            isDateGreater = false;
                        }
                    }
                }, id + "?showSubTasks=true", "tasks");
            }

                if (isDateInRange) {
                    if (withinRange) {
                        let data = JSON.stringify(isValid.data);
                        let url = `api/${type}/${id}`;
                        let xmlHttp = new XMLHttpRequest();
                        xmlHttp.open("PUT", url, false);
                        xmlHttp.setRequestHeader('Content-type', 'application/json; charset=utf-8');
                        xmlHttp.onreadystatechange = function () {
                            if (xmlHttp.readyState == 4 || xmlHttp.status == 200) {
                                showMessage(xmlHttp.responseText, "success");
                            }
                        }
                        xmlHttp.send(data);
                    } else {
                        showMessage(`You Selected ${formDatesDays - daysInST} days and you are allowd to select ${daysInMT - daysInST} days only`, "error");
                    }

                } else {
                    showMessage(`Start/End Date is not in align with the main task start/end date`, "error");
                }
        } else {
            showMessage("Start Date or End Date is not in the correct range", "error");
        }
    } else {
        showMessage("please make sure all fields are filled", "error");
    }

}

function updateData(id, type) {
    let isValid = getFormData();
    if (isValid.isValid) {
        let data = JSON.stringify(isValid.data);
        let url = `api/${type}/${id}`;
        let xmlHttp = new XMLHttpRequest();
        xmlHttp.open("PUT", url, false);
        xmlHttp.setRequestHeader('Content-type', 'application/json; charset=utf-8');
        xmlHttp.onreadystatechange = function () {
            if (xmlHttp.readyState == 4 || xmlHttp.status == 200) {
                showMessage(xmlHttp.responseText, "success");
            }
        }
        xmlHttp.send(data);
    } else {
        showMessage("please make sure all fields are filled", "error");
    }

}



function showMessage(msg,type) {
    let div = document.createElement('div');
    let span = document.createElement('span');
    div.classList.add('msg');
    div.classList.add(type);
    div.classList.add("slowDown");
    span.appendChild(document.createTextNode(msg));
    div.appendChild(span);
    document.querySelector('body').appendChild(div);
    setTimeout(function () {
        let el = document.querySelector('.msg');
        el.classList.remove('slowDown');
        el.classList.add('slowUp');
        setTimeout(function () {
            el.parentNode.removeChild(el);
        }, 500);
    }, 3000);

}



function TableTemplate(data) {
    let totalDays = 0;
    let upToDay = 0;
    let subTaskDays = 0;
    if (data.length > 0) {
        let t = `
    <table class="m-t">
            <tr>
                <th>#</th>
                <th>Task Name</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Total Days ---> Total Sub tasks days</th>
                <th>Details</th>
                <th>Action</th>
            </tr>`

        data.forEach(function (el, index1) {
            if (el.subTasks.length > 0) {
                subTaskDays = el.subTasks.reduce(function (values, current) {
                    return values + getDaysTwoDates(current.subTaskStartDate, current.subTaskEndDate);
                }, 0);
                let subTasks = `
   <tr class="sub-task">
   <td colspan="8">
   <table class="s-t">
       <tr>
           <th>#</th>
           <th>Sub Task Name</th>
           <th>Start Date</th>
           <th>End Date</th>
           <th>Total Days</th>
           <th>Remaining Days</th>
           <th>Details</th>
           <th>Action</th>
       </tr>`;
                el.subTasks.forEach(function (el1, index) {
                    totalDays = getDaysTwoDates(el1.subTaskStartDate, el1.subTaskEndDate);
                    upToDay = getDaysTwoDates(new Date(), el1.subTaskEndDate) < 0 ? 0 : getDaysTwoDates(new Date(), el1.subTaskEndDate);
                    subTasks += `
                    <tr id="st-${el1.subTaskID}">
                        <td><span class='number'>${index + 1}</span></td>
                        <td>${el1.subTaskName}</td>
                        <td>${formateDate(el1.subTaskStartDate)}</td>
                        <td>${formateDate(el1.subTaskEndDate)}</td>
                        <td>${totalDays}</td>
                        <td>${upToDay}</td>
                        <td>${el1.subTaskDetails}</td>
                <td colspan="2">
    
            ${upToDay == 0 && totalDays == subTaskDays ? "":"<i class='far fa-edit'   data-action='edit' data-type='subTasks' data-id='"+el1.subTaskID+"'></i>"}
            ${upToDay == 0 && totalDays == subTaskDays ? "" : "<i class='fas fa-trash-alt'  data-action='delete' data-type='subTasks' data-id='"+el1.subTaskID+"'></i>  "}

    
                </td>
                 </tr>
    `;
                });

                subTasks += `
   </table>
    </td>
   </tr>`;
                totalDays = getDaysTwoDates(el.taskStartDate, el.taskEndDate);
                t += `
            <tr>
                        <td><span class='number'>${index1 + 1}</span></td>
                <td>${el.taskName}</td>
                <td>${formateDate(el.taskStartDate)}</td>
                <td>${formateDate(el.taskEndDate)}</td>
                 <td><span class='number'>${totalDays}</span> ---> <span class='number'>${subTaskDays}</span></td>
                <td>${el.taskDetails}</td>
                <td colspan="2">
<i class="fas fa-eye" data-action='showSub'></i>
   ${totalDays == subTaskDays ? "" : "<i class='fas fa-plus-circle'  data-action='addSubTask' data-id='" + el.mainTaskID + "'></i>"}
 <i class="fas fa-trash-alt"  data-action='delete' data-type='tasks' data-id='${el.mainTaskID}'></i>  
                </td>
${subTasks}
            </tr> `;
// ${ totalDays == subTaskDays ? "" : "<i class='far fa-edit' data-id='" + el.mainTaskID + "' data-action='edit' data-type='tasks'></i>" }

            } else {
                totalDays = getDaysTwoDates(el.taskStartDate, el.taskEndDate);
                upToDay = getDaysTwoDates(new Date(), el.taskEndDate);
                subTaskDays = 0;
                console.log("Nesx " + upToDay);
                t += `
            <tr>
                        <td><span class='number'>${index1 + 1}</span></td>
                <td>${el.taskName}</td>
             <td>${formateDate(el.taskStartDate)}</td>
                <td>${formateDate(el.taskEndDate)}</td>
                 <td><span class='number'>${totalDays}</span> ---> <span class='number'>${subTaskDays}</span></td>
                <td>${el.taskDetails}</td>
                <td colspan="2">
   ${upToDay == 0   ? "" : "<i class='fas fa-plus-circle' data-action='addSubTask' data-id='" + el.mainTaskID + "'></i>"}
 ${upToDay == 0 ? "" : "<i class='far fa-edit' data-id='" + el.mainTaskID + "' data-action='edit' data-type='tasks'></i>"}
 ${upToDay == 0 ? "" : "<i class='fas fa-trash-alt'  data-action='delete' data-type='tasks' data-id='" + el.mainTaskID+"'></i>"}
          
</td>
            </tr>`;
            }
        });

        t += `
        </table>
    `;
        document.querySelector('.data').innerHTML = t;
    } else {
        document.querySelector('.data').innerHTML = "<span>No Tasks have been added Yet</span>";
    }
}